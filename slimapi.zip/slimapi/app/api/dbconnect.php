<?php
  $host = "localhost";
  $user = "root";
  $pass = "";
  $db_name = "library";
  $db = new mysqli($host,$user,$pass,$db_name);
?>
