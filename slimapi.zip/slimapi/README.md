URL                    HTTP Method         Operation
---------------------------------------------------------------------------
/api/books             GET                 Return list of books
/api/books/{id}        GET                 Return book with given {id}
/api/books             POST                Adds new book
/api/books/{id}        PUT                 Update book with given {id}
/api/books/{id}        DELETE              Delete book with given {id}
